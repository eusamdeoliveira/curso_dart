class Cliente {
  var nome;
  var cpf;

  Cliente({this.nome, this.cpf});
}