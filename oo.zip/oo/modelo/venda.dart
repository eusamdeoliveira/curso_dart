import 'cliente.dart';
import 'venda_item.dart';

class Venda {
  Cliente ?cliente;
  
}
